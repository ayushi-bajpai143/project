This is to inform you that to run this project you need to create "Virtual Environment". Virtual Environment provides an isolation environment for python files.

The following steps will guide you to create Virtutal Environment and this code should be executed in cmd and directory will be the folder in which you stored this project.
	
For instance, my directory is E:\FPD

Step 1 creating virtutal environment as myvenv:- E:\FPD>python -m venv myvenv 
Step 2 activating virtual environment:- E:\FPD>myvenv\Scripts\activate
Step 3 installing requirement files to run this project:- (myvenv) E:\FPD>pip install -r requirements.txt
Step 4 project on server:- (myvenv) E:\FPD>python manage.py runserver

The above mentioned requirements.txt file is already provided with project.

After following the above given steps, you are good to go and can run this astonishing project.






